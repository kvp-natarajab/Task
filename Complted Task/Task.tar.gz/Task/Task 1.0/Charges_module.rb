module Charges
	BASIC_USAGE_CHARGE=1.00
	NORMAL_USAGE_CHARGE=2.70
	MORE_USAGE_CHARGE=4.00
	TAX=0.15
	FIXED_CHARGES=50.0
	def Charges.generate_bill
	end
	def Charges.calculate_bill
	end
end

